<html>
<head><title>Edit Caption</title></head><body>
Edit Caption

<form action='/picture/edit/<?php echo $data['picture_id'] ?>' method='post'>
    Caption: <input type='text' name='caption' value='' /><br>
	<input type='submit' name='action' value='Save changes' />
</form>
</body></html>