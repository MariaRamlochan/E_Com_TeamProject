<html>
<head>
	<title>Picture upload</title>
</head>
<body>

	<h1>Upload a new picture</h1>
	<form method="post" enctype="multipart/form-data" action="/picture/index">
		Select an image file to upload:<input type="file" name="newPicture"><br>
		Caption: <input type='text' name='caption' value='' /><br>
		<input type="submit" name="action">
	</form>

</body>
</html>