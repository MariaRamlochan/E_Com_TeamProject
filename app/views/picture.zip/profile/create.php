<html>
<head><title>Add an Animal</title></head><body>
Add a new profile
<?php
$user_id = $_SESSION['user_id'];
echo "My user_id " . $_SESSION["user_id"] . ".<br>";
?>
<form action='/profile/create' method='post'>
	First Name: <input type='text' name='first_name' /><br>
	Middle Name: <input type='text' name='middle_name' /><br>
	Last Name: <input type='text' name='last_name' /><br>
	<input type='submit' name='action' value='Create' />
</form>

</body></html>