<html>
<head>
    <title>Profile index</title>
</head>
<body>
    <h2>Menu</h2>
    <a href="/Main/changePassword/">Change password</a><br>
    <a href="/Main/setup2fa">Setup2fa</a><br>
    <a href="/profile/edit">Edit my profile</a><br>
    <a href="/profile/search">Search for other profiles</a><br>
    <a href="/Message/index">Inbox(<?php echo $data['messages_count'] ?>)</a><br>
    <a href="/Main/logout">Logout</a><br>
    <h2>Profile</h2>
    <h4>Inbox</h4>
    <p>Messages(public):</p>
    <?php 
    if(count($data['messages'])){
        foreach($data['messages'] as $message){
            echo "<li>".$message->username." : ".$message->message."</li>";
        }
    }
    ?>
    <br>
    <p>First Name : <?php echo $data['user']->first_name ?></p> 
    <p>Middle Name : <?php echo $data['user']->middle_name ?></p> 
    <p>Last Name : <?php echo $data['user']->last_name ?></p>
    <h4>Pictures</h4>
    <h4><a href="/picture/index">Upload picture</a></h4>
        <?php
        if(count($data['pictures'])){
            foreach($data['pictures'] as $picture){
                echo "<img alt='picture' style='width:185px' src='/uploads/".$picture->filename."'><br>";
                echo "<p><a href=/picture/delete/".$picture->picture_id.">Delete picture</a></p>";
                echo "<p><a href=/picture/edit/".$picture->picture_id.">Edit caption</a></p>";
                echo "<p>Caption: ".$picture->caption."</p>";
            }
        }
        ?>
</body>
</html>


