<html>
<head>
    <title>Profile index</title>
</head>

<body>
<h2>Menu</h2>
    <a href="/Main/changePassword/">Change password</a><br>
    <a href="/Main/setup2fa">Setup2fa</a><br>
    <a href="/profile/index">My profile</a><br>
    <a href="/Message/index">Inbox(<?php echo $data['messages_count'] ?>)</a><br>
    <a href="/Main/logout">Logout</a><br>
<h2>Search for other profiles</h2>
<form action='/profile/search' method='post'>
	User name: <input type='text' name='user_name' value='' />
	<input type='submit' name='action' value='Search' />
</form>

<table>
	<tr>
        <th>User Id</th>
        <th>First name</th>
        <th>Middle name</th>
        <th>Last name</th>
        <th>User name</th>
        <th>actions</th>
    </tr>
<?php

    if(count($data['users'])){

        foreach($data['users'] as $profile){
            echo "<tr>
                    <td>$profile->user_id</td>
                    <td>$profile->first_name</td>
                    <td>$profile->middle_name</td>
                    <td>$profile->last_name</td>
                    <td>$profile->username</td>
                    <td>
                        <a href='/profile/view_profile/".$profile->user_id."/".$profile->profile_id."'>view profile</a>
                    </td>
                </tr>";
        }
    }
?>
</table>

</body>
</html>