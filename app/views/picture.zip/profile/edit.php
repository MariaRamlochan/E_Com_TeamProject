<html>
<head><title>Edit password</title></head><body>
Edit password
<form action='/profile/edit/' method='post'>
	First Name: <input type='text' name='first_name' value='<?php echo $data->first_name; ?>' /><br>
	Middle Name: <input type='text' name='middle_name' value='<?php echo $data->middle_name; ?>' /><br>
	Last Name: <input type='text' name='last_name' value='<?php echo $data->last_name; ?>' /><br>
	<input type='submit' name='action' value='Save changes' />
</form>

</body></html>