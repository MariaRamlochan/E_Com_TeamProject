<html>
<head><title>Register</title></head><body>
<h2>Register a new user</h2>
<form action='' method='post'>
	Username: <input type='text' name='username' /><br>
	Password: <input type='password' name='password' /><br>
	Password confirmation: <input type='password' name='password_confirm' /><br>
	<br>
	<input type='submit' name='action' value='Register' />
	<a href='/Main/login'>Login</a>
</form>

</body></html>