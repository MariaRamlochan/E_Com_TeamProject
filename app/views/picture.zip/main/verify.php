<html>
<head>
<title>2fa verify</title>
</head>
<body>
<h2>Menu</h2>
<a href="/Main/logout">Logout</a><br>
Please Verify 2fa :
<form method="post" action="/Main/verify2fa">
<label>Current code:<input type="text" name="currentCode"
/></label>
<input type="submit" name="action" value="Verify code" />
</form>
</body>
</html>