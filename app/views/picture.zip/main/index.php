<html>
<head>
    <title>Index</title>
</head>
<body>
<h2>Menu</h2>
  <a href="/Profile/index/">My profile</a><br>
  <a href="/Main/changePassword/">Change password</a><br>
  <a href="/Main/setup2fa">Setup2fa</a><br>
  <a href="/Main/logout">Logout</a><br>
</body>
</html>