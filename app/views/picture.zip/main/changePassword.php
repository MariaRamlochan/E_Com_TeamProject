<html>
<head>
    <title>Change password</title>
</head>
<body>
<h2>Menu</h2>
  <a href="/Profile/index/">My profile</a><br>
  <a href="/Main/setup2fa">Setup2fa</a><br>
  <a href="/Main/logout">Logout</a><br>
<form method='post' action=''>
		<p>Current Password: <input type="password" name="current_password" value='' /></p>
		<p>New Password: <input type="password" name="new_password" value='' /></p>
		<p>Confirm New Password: <input type="password" name="new_password_confirm" /></p>
		<input type="submit" name="action" value="Change Password"/>
	</form>
</body></html>